//This is a template that comes included with RNBOp5lib.js to show how to interface with the RNBO objects

//Be sure that inpComp.export.json always stays in the patches folder and that any patch you want to access also goes in that folder

//When setting up your file or if index.html is rewritten automatically(happens when a new tab is added in p5) include this line in the header:
//  <script language="javascript" type="text/javascript" src="https://cdn.cycling74.com/rnbo/latest/rnbo.min.js"></script>


const { createDevice } = RNBO; //Do not delete or move

let rnboloaded = false; //set this var so that the rest of you code can occur after the patches load

//declare all RNBOPatch vars here:
let example;

async function audioSetup() {
  audioContextSetup();  
  // you need these two lines for every RNBO patch you want included
  example = new RNBOPatch('patches/NAMEOFYOURPATCH.export.json'); 
  await example.init();
  // use this next line only to test if sound is coming out. typically this is only used for the last 2 ch stereo out patch in your chain
  example.masterOut(); 
  rnboloaded = true;
}

function setup() {
  let cnv = createCanvas(windowWidth, windowHeight);
  audioSetup();
}


function draw() {
  startAudioContext();
  if (rnboloaded) {
  //Your code here -- read dcoumetation on how to use the RNBOPatch object and its functions
  
  
  
  
  
  
  }
}
